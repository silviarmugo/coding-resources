public class Student {
    private String name;
    private String courseName;
    private String studentClass;
    private int age;
    private int admission;
    private double balance;

        public String getName(){
            return name;
        }
        public void setName(String name){
            this.name = name;
        }
        public String getCourseName(){
            return courseName;
        }
        public void setCourseName(String courseName){
            this.courseName = courseName;
        }
        public String getStudentClass(){
            return studentClass;
        }
        public void setStudentClass(String studentClass){
            this.studentClass = studentClass;
        }
        public int getAge(){
            return age;
        }
        public void setAge(int age){
            this.age = age;
        }
        public int getAdmission(){
            return admission;
        }
        public void setAdmission(int admission){
            this.admission = admission;
        }
        public double getBalance(){
            return balance;
        }
        public void setBalance(double balance){
            this.balance = balance;
        }
        
    }
    

   